﻿(function() { 
	'use strict'; 
	
	angular.module('common.logger', []); 
})(); 
