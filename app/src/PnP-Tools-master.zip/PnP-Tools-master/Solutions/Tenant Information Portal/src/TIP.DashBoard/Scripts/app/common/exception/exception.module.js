﻿(function () {
    'use strict';

    angular.module('common.exception', ['common.logger']);
})();