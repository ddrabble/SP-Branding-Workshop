# Change Log

## Version 1.0.3
* Remove unneccessary images
* Office UI Fabric  https://github.com/ngOfficeUIFabric
* JavaScript restructuring

## Version 1.0.2
* Dashboard controller refractoring and priming the promises
* Added Dashboard chart labels translation
* Refactoring of JavaScript logging
* Added Azure Applications expiring

## Version 1.0.1
* Formatted JSON Dates in the UX

## Version 1.0.0
* Initial Version