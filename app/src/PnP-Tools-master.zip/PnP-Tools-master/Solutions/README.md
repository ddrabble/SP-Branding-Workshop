# Patterns and Practices - Solutions #
Different kind of automation solutions and tools for SharePoint and Office 365 in general. See readme from specific folders for exact details. 

![](http://i.imgur.com/I2VYM3a.png)
 
# "Sharing is caring" #

