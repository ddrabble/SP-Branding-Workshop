# Patterns and Practices - Scripts #
Different kind of automation scripts for SharePoint and Office 365 in general. See readme from specific folders for exact details. 

![](http://i.imgur.com/I2VYM3a.png)
 
# "Sharing is caring" #

